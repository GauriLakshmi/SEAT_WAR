import React, { useState, useEffect } from 'react';
import { RotateCcw, Target, TrendingUp, TrendingDown } from 'lucide-react';
import { GameProps } from '../../types';

export default function NumberGuessing({ onWin, onLose, onBack }: GameProps) {
  const [targetNumber, setTargetNumber] = useState<number>(0);
  const [guess, setGuess] = useState<string>('');
  const [attempts, setAttempts] = useState<number>(0);
  const [feedback, setFeedback] = useState<string>('');
  const [gameStatus, setGameStatus] = useState<'playing' | 'won' | 'lost'>('playing');
  const [guessHistory, setGuessHistory] = useState<Array<{guess: number, feedback: string}>>([]);

  useEffect(() => {
    setTargetNumber(Math.floor(Math.random() * 100) + 1);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const guessNumber = parseInt(guess);
    
    if (isNaN(guessNumber) || guessNumber < 1 || guessNumber > 100) {
      setFeedback('Please enter a number between 1 and 100');
      return;
    }

    const newAttempts = attempts + 1;
    setAttempts(newAttempts);

    let feedbackText = '';
    if (guessNumber === targetNumber) {
      setGameStatus('won');
      feedbackText = '🎉 Perfect! You found it!';
      setTimeout(() => onWin(), 1500);
    } else if (guessNumber < targetNumber) {
      feedbackText = 'Too low! Try higher 📈';
    } else {
      feedbackText = 'Too high! Try lower 📉';
    }

    setGuessHistory(prev => [...prev, { guess: guessNumber, feedback: feedbackText }]);
    setFeedback(feedbackText);

    if (newAttempts >= 7 && guessNumber !== targetNumber) {
      setGameStatus('lost');
      setFeedback(`Game over! The number was ${targetNumber}`);
      setTimeout(() => onLose(), 1500);
    }

    setGuess('');
  };

  return (
    <div className="text-center space-y-8">
      <div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Number Guessing Game</h3>
        <p className="text-gray-600">Guess the number between 1 and 100!</p>
        <div className="mt-4 text-lg font-semibold">
          Attempts: {attempts}/7
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-100 to-indigo-100 p-8 rounded-2xl">
        <div className="flex items-center justify-center gap-2 mb-6">
          <Target className="text-blue-600" size={24} />
          <span className="text-xl font-bold text-blue-600">Find the Hidden Number!</span>
        </div>

        {feedback && (
          <div className={`text-lg font-bold p-4 rounded-xl mb-6 flex items-center justify-center gap-2 ${
            feedback.includes('Perfect') ? 'bg-green-200 text-green-800' :
            feedback.includes('low') ? 'bg-orange-200 text-orange-800' :
            feedback.includes('high') ? 'bg-red-200 text-red-800' :
            'bg-yellow-200 text-yellow-800'
          }`}>
            {feedback.includes('low') && <TrendingUp size={20} />}
            {feedback.includes('high') && <TrendingDown size={20} />}
            {feedback}
          </div>
        )}

        {gameStatus === 'playing' && (
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="number"
              value={guess}
              onChange={(e) => setGuess(e.target.value)}
              placeholder="Enter your guess (1-100)"
              min="1"
              max="100"
              className="w-full max-w-xs mx-auto p-4 border-2 border-gray-300 rounded-xl text-lg text-center font-semibold transition-all duration-300 focus:border-blue-500 focus:outline-none focus:shadow-lg"
              autoFocus
              disabled={gameStatus !== 'playing'}
            />
            <button
              type="submit"
              className="bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
              disabled={gameStatus !== 'playing'}
            >
              Make Guess
            </button>
          </form>
        )}

        {guessHistory.length > 0 && (
          <div className="mt-6 max-h-32 overflow-y-auto">
            <h4 className="text-sm font-semibold text-gray-600 mb-2">Guess History:</h4>
            <div className="space-y-1">
              {guessHistory.slice(-5).map((entry, index) => (
                <div key={index} className="text-sm text-gray-600 flex items-center justify-center gap-2">
                  <span className="font-mono">{entry.guess}</span>
                  <span>→</span>
                  <span>{entry.feedback}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <button
        onClick={onBack}
        className="bg-gradient-to-r from-gray-500 to-gray-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
      >
        <span className="flex items-center gap-2">
          <RotateCcw size={18} />
          Back to Seats
        </span>
      </button>
    </div>
  );
}
