import React, { useState, useEffect } from 'react';
import { RotateCcw, Play, Pause } from 'lucide-react';
import { GameProps } from '../../types';

const actions = [
  { name: 'Clap', emoji: '👏', color: 'bg-yellow-500', hoverColor: 'hover:bg-yellow-600' },
  { name: 'Jump', emoji: '🦘', color: 'bg-green-500', hoverColor: 'hover:bg-green-600' },
  { name: 'Spin', emoji: '🌪️', color: 'bg-blue-500', hoverColor: 'hover:bg-blue-600' },
  { name: 'Wave', emoji: '👋', color: 'bg-purple-500', hoverColor: 'hover:bg-purple-600' }
];

export default function SimonSays({ onWin, onLose, onBack }: GameProps) {
  const [sequence, setSequence] = useState<number[]>([]);
  const [playerSequence, setPlayerSequence] = useState<number[]>([]);
  const [showingSequence, setShowingSequence] = useState(false);
  const [activeAction, setActiveAction] = useState<number | null>(null);
  const [round, setRound] = useState(1);
  const [gameStatus, setGameStatus] = useState<'waiting' | 'showing' | 'playing' | 'won' | 'lost'>('waiting');
  const [instruction, setInstruction] = useState('');

  useEffect(() => {
    startNewRound();
  }, []);

  const startNewRound = () => {
    const newSequence = [...sequence, Math.floor(Math.random() * actions.length)];
    setSequence(newSequence);
    setPlayerSequence([]);
    setGameStatus('showing');
    setInstruction('Watch carefully and remember the sequence!');
    showSequence(newSequence);
  };

  const showSequence = async (seq: number[]) => {
    setShowingSequence(true);
    
    for (let i = 0; i < seq.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setActiveAction(seq[i]);
      setInstruction(`Simon says: ${actions[seq[i]].name}!`);
      await new Promise(resolve => setTimeout(resolve, 600));
      setActiveAction(null);
      setInstruction('');
    }
    
    setShowingSequence(false);
    setGameStatus('playing');
    setInstruction('Now repeat the sequence!');
  };

  const handleActionClick = (actionIndex: number) => {
    if (showingSequence || gameStatus !== 'playing') return;

    const newPlayerSequence = [...playerSequence, actionIndex];
    setPlayerSequence(newPlayerSequence);

    // Check if this action is correct
    if (newPlayerSequence[newPlayerSequence.length - 1] !== sequence[newPlayerSequence.length - 1]) {
      setGameStatus('lost');
      setInstruction('❌ Wrong sequence! You lose!');
      setTimeout(() => onLose(), 1500);
      return;
    }

    // Check if sequence is complete
    if (newPlayerSequence.length === sequence.length) {
      if (round >= 5) {
        setGameStatus('won');
        setInstruction('🎉 Amazing! You completed all 5 rounds!');
        setTimeout(() => onWin(), 1500);
      } else {
        setRound(round + 1);
        setInstruction('✅ Correct! Get ready for the next round...');
        setTimeout(() => startNewRound(), 1500);
      }
    }
  };

  return (
    <div className="text-center space-y-8">
      <div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Simon Says</h3>
        <p className="text-gray-600">Watch the sequence and repeat it exactly!</p>
        <div className="mt-4 text-lg font-semibold">
          Round {round} of 5 | Sequence length: {sequence.length}
        </div>
      </div>

      <div className="bg-gradient-to-r from-pink-100 to-purple-100 p-8 rounded-2xl">
        <div className="flex items-center justify-center gap-2 mb-6">
          {showingSequence ? <Play className="text-purple-600" size={24} /> : <Pause className="text-purple-600" size={24} />}
          <span className="text-xl font-bold text-purple-600">
            {showingSequence ? 'Simon is showing...' : 'Your turn!'}
          </span>
        </div>

        {instruction && (
          <div className={`text-lg font-bold p-4 rounded-xl mb-6 ${
            instruction.includes('Simon says') ? 'bg-purple-200 text-purple-800' :
            instruction.includes('Watch') ? 'bg-blue-200 text-blue-800' :
            instruction.includes('repeat') ? 'bg-green-200 text-green-800' :
            instruction.includes('Wrong') ? 'bg-red-200 text-red-800' :
            instruction.includes('Amazing') ? 'bg-yellow-200 text-yellow-800' :
            'bg-gray-200 text-gray-800'
          }`}>
            {instruction}
          </div>
        )}

        <div className="grid grid-cols-2 gap-6 max-w-md mx-auto">
          {actions.map((action, index) => (
            <button
              key={action.name}
              onClick={() => handleActionClick(index)}
              disabled={showingSequence || gameStatus === 'won' || gameStatus === 'lost'}
              className={`
                p-8 rounded-2xl transition-all duration-200 border-4 border-white shadow-lg text-white font-bold text-lg
                ${action.color} ${action.hoverColor}
                ${activeAction === index ? 'scale-110 brightness-125 border-white shadow-xl' : ''}
                ${showingSequence ? 'cursor-not-allowed' : 'hover:scale-105'}
                disabled:opacity-50
              `}
            >
              <div className="text-4xl mb-2">{action.emoji}</div>
              <div>{action.name}</div>
            </button>
          ))}
        </div>

        {gameStatus === 'playing' && (
          <div className="mt-6 text-sm text-gray-600">
            Progress: {playerSequence.length}/{sequence.length}
          </div>
        )}
      </div>

      <button
        onClick={onBack}
        className="bg-gradient-to-r from-gray-500 to-gray-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
      >
        <span className="flex items-center gap-2">
          <RotateCcw size={18} />
          Back to Seats
        </span>
      </button>
    </div>
  );
}
