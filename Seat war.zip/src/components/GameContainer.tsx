import React from 'react';
import { GameType } from '../types';
import TicTacToe from './games/TicTacToe';
import JumbledWords from './games/JumbledWords';
import RockPaperScissors from './games/RockPaperScissors';
import ColorMemory from './games/ColorMemory';
import NumberGuessing from './games/NumberGuessing';
import SimonSays from './games/SimonSays';
import MathChallenge from './games/MathChallenge';

interface GameContainerProps {
  gameType: GameType;
  onGameWin: () => void;
  onGameLose: () => void;
  onBackToSeats: () => void;
}

export default function GameContainer({ gameType, onGameWin, onGameLose, onBackToSeats }: GameContainerProps) {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">OOPS! The seat is booked.</h2>
        <p className="text-lg text-gray-600">Win the game to claim this seat! 🏆</p>
      </div>

      <div className="bg-gray-50/60 rounded-3xl p-8 border border-white/20">
        {gameType === 'ticTacToe' && (
          <TicTacToe onWin={onGameWin} onLose={onGameLose} onBack={onBackToSeats} />
        )}
        {gameType === 'jumbledWords' && (
          <JumbledWords onWin={onGameWin} onLose={onGameLose} onBack={onBackToSeats} />
        )}
        {gameType === 'rockPaperScissors' && (
          <RockPaperScissors onWin={onGameWin} onLose={onGameLose} onBack={onBackToSeats} />
        )}
        {gameType === 'colorMemory' && (
          <ColorMemory onWin={onGameWin} onLose={onGameLose} onBack={onBackToSeats} />
        )}
        {gameType === 'numberGuessing' && (
          <NumberGuessing onWin={onGameWin} onLose={onGameLose} onBack={onBackToSeats} />
        )}
        {gameType === 'simonSays' && (
          <SimonSays onWin={onGameWin} onLose={onGameLose} onBack={onBackToSeats} />
        )}
        {gameType === 'mathChallenge' && (
          <MathChallenge onWin={onGameWin} onLose={onGameLose} onBack={onBackToSeats} />
        )}
      </div>
    </div>
  );
}
