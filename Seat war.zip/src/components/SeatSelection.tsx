import React from 'react';
import { Crown, CheckCircle, RotateCcw } from 'lucide-react';
import { User } from '../types';

interface SeatSelectionProps {
  user: User;
  bookedSeats: Set<number>;
  selectedSeat: number | null;
  onSeatSelect: (seatNumber: number) => void;
  onConfirmBooking: () => void;
  onBackToSeats: () => void;
}

export default function SeatSelection({
  user,
  selectedSeat,
  onSeatSelect,
  onConfirmBooking
}: SeatSelectionProps) {
  const generateSeats = () => {
    const seats = [];
    for (let i = 1; i <= 56; i++) {
      const isVip = i <= 16;
      const isSelected = selectedSeat === i;
      
      seats.push(
        <button
          key={i}
          onClick={() => onSeatSelect(i)}
          className={`
            seat relative w-16 h-16 rounded-2xl font-semibold text-sm transition-all duration-300 border-2 overflow-hidden
            ${isVip 
              ? 'bg-gradient-to-br from-orange-400 to-orange-600 border-orange-700 text-white shadow-lg shadow-orange-200' 
              : 'bg-gradient-to-br from-green-400 to-green-600 border-green-700 text-white shadow-lg shadow-green-200'
            }
            ${isSelected 
              ? 'scale-110 bg-gradient-to-br from-purple-500 to-blue-600 shadow-xl shadow-purple-300 z-10' 
              : 'hover:scale-105'
            }
            before:absolute before:inset-0 before:bg-gradient-to-br before:from-white/20 before:to-white/10 before:opacity-0 hover:before:opacity-100 before:transition-opacity before:duration-300
          `}
        >
          {i}
          {isVip && (
            <Crown 
              size={12} 
              className="absolute -top-1 -right-1 text-yellow-300" 
            />
          )}
        </button>
      );
    }
    return seats;
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-2">
          Select Your Seat
        </h1>
        <p className="text-lg">
          Welcome back, <span className="text-purple-600 font-semibold">{user.name}</span>!
        </p>
        <p className="text-purple-600 font-medium mt-2">🎯 Try your luck and book your seat</p>
      </div>

      <div className="flex justify-center gap-8 p-6 bg-gray-50/60 rounded-2xl border border-white/20">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 bg-gradient-to-br from-green-400 to-green-600 rounded-lg shadow-sm"></div>
          <span className="font-medium text-gray-700">Regular Seats</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 bg-gradient-to-br from-orange-400 to-orange-600 rounded-lg shadow-sm"></div>
          <span className="font-medium text-gray-700">VIP Experience</span>
        </div>
      </div>

      <div className="grid grid-cols-8 gap-3 max-w-2xl mx-auto p-8 bg-gray-50/60 rounded-3xl border border-white/30">
        {generateSeats()}
      </div>

      {selectedSeat && (
        <div className="flex justify-center">
          <button
            onClick={onConfirmBooking}
            className="bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold py-4 px-8 rounded-2xl transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-purple-200 relative overflow-hidden group"
          >
            <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-500"></span>
            <span className="relative flex items-center gap-2">
              <CheckCircle size={20} />
              Confirm Booking
            </span>
          </button>
        </div>
      )}
    </div>
  );
}
