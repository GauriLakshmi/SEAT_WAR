import React, { useState } from 'react';
import { User, Phone, Rocket } from 'lucide-react';
import { User as UserType } from '../types';

interface LoginFormProps {
  onLogin: (user: UserType) => void;
}

export default function LoginForm({ onLogin }: LoginFormProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && phone.trim()) {
      onLogin({ name: name.trim(), phone: phone.trim() });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="text-center">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-4">
          🎪 SeatCraft
        </h1>
        <p className="text-xl text-purple-600 font-medium opacity-90">
          Your premium seat booking experience
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 uppercase tracking-wide">
            <User size={16} />
            Full Name
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your full name"
            className="w-full p-5 border-2 border-gray-200 rounded-2xl text-lg transition-all duration-300 bg-white/80 hover:border-purple-300 focus:border-purple-500 focus:outline-none focus:-translate-y-1 focus:shadow-lg focus:shadow-purple-100"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 uppercase tracking-wide">
            <Phone size={16} />
            Phone Number
          </label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Enter your phone number"
            className="w-full p-5 border-2 border-gray-200 rounded-2xl text-lg transition-all duration-300 bg-white/80 hover:border-purple-300 focus:border-purple-500 focus:outline-none focus:-translate-y-1 focus:shadow-lg focus:shadow-purple-100"
            required
          />
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold py-5 px-8 rounded-2xl text-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-purple-200 active:translate-y-0 relative overflow-hidden group"
      >
        <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-500"></span>
        <span className="relative flex items-center justify-center gap-2">
          <Rocket size={20} />
          Start Booking Journey
        </span>
      </button>
    </form>
  );
}
