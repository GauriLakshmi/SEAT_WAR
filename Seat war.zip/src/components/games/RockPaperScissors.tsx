import React, { useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { GameProps } from '../../types';

type Choice = 'rock' | 'paper' | 'scissors';

export default function RockPaperScissors({ onWin, onLose, onBack }: GameProps) {
  const [playerChoice, setPlayerChoice] = useState<Choice | null>(null);
  const [computerChoice, setComputerChoice] = useState<Choice | null>(null);
  const [result, setResult] = useState<string>('');
  const [playerWins, setPlayerWins] = useState(0);
  const [computerWins, setComputerWins] = useState(0);

  const choices: { [key in Choice]: string } = {
    rock: '🪨',
    paper: '📄',
    scissors: '✂️'
  };

  const playGame = (playerMove: Choice) => {
    const moves: Choice[] = ['rock', 'paper', 'scissors'];
    const computerMove = moves[Math.floor(Math.random() * moves.length)];
    
    setPlayerChoice(playerMove);
    setComputerChoice(computerMove);

    let gameResult = '';
    if (playerMove === computerMove) {
      gameResult = "It's a tie! Try again.";
    } else if (
      (playerMove === 'rock' && computerMove === 'scissors') ||
      (playerMove === 'paper' && computerMove === 'rock') ||
      (playerMove === 'scissors' && computerMove === 'paper')
    ) {
      gameResult = 'You win this round!';
      const newPlayerWins = playerWins + 1;
      setPlayerWins(newPlayerWins);
      
      if (newPlayerWins >= 3) {
        setTimeout(() => onWin(), 1500);
        return;
      }
    } else {
      gameResult = 'Computer wins this round!';
      const newComputerWins = computerWins + 1;
      setComputerWins(newComputerWins);
      
      if (newComputerWins >= 3) {
        setTimeout(() => onLose(), 1500);
        return;
      }
    }
    
    setResult(gameResult);
  };

  return (
    <div className="text-center space-y-8">
      <div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Rock Paper Scissors</h3>
        <p className="text-gray-600">Best of 5 - First to win 3 rounds wins!</p>
      </div>

      <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-6 rounded-2xl">
        <div className="flex justify-between items-center mb-4">
          <div className="text-lg font-semibold">
            You: <span className="text-blue-600">{playerWins}</span>
          </div>
          <div className="text-lg font-semibold">
            Computer: <span className="text-red-500">{computerWins}</span>
          </div>
        </div>

        {playerChoice && computerChoice && (
          <div className="flex justify-around items-center mb-6">
            <div className="text-center">
              <div className="text-6xl mb-2">{choices[playerChoice]}</div>
              <p className="font-semibold text-blue-600">You</p>
            </div>
            <div className="text-2xl font-bold text-gray-500">VS</div>
            <div className="text-center">
              <div className="text-6xl mb-2">{choices[computerChoice]}</div>
              <p className="font-semibold text-red-500">Computer</p>
            </div>
          </div>
        )}

        {result && (
          <div className={`text-lg font-bold p-4 rounded-xl ${
            result.includes('You win') ? 'bg-green-200 text-green-800' :
            result.includes('Computer wins') ? 'bg-red-200 text-red-800' :
            'bg-yellow-200 text-yellow-800'
          }`}>
            {result}
          </div>
        )}
      </div>

      <div className="space-y-4">
        <p className="text-lg font-semibold text-gray-700">Choose your move:</p>
        <div className="flex justify-center gap-4">
          {(Object.keys(choices) as Choice[]).map((choice) => (
            <button
              key={choice}
              onClick={() => playGame(choice)}
              className="bg-white border-2 border-gray-300 rounded-2xl p-6 text-6xl transition-all duration-300 hover:scale-110 hover:border-purple-400 hover:shadow-lg hover:shadow-purple-100"
            >
              {choices[choice]}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={onBack}
        className="bg-gradient-to-r from-gray-500 to-gray-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
      >
        <span className="flex items-center gap-2">
          <RotateCcw size={18} />
          Back to Seats
        </span>
      </button>
    </div>
  );
}
