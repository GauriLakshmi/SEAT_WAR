import React, { useState, useEffect } from 'react';
import { RotateCcw, Send } from 'lucide-react';
import { GameProps } from '../../types';

export default function JumbledWords({ onWin, onLose, onBack }: GameProps) {
  const [word, setWord] = useState('');
  const [jumbledWord, setJumbledWord] = useState('');
  const [userAnswer, setUserAnswer] = useState('');

  useEffect(() => {
    const words = ['ELEPHANT', 'COMPUTER', 'RAINBOW', 'MOUNTAIN', 'KEYBOARD', 'BUTTERFLY', 'DIAMOND', 'ADVENTURE'];
    const selectedWord = words[Math.floor(Math.random() * words.length)];
    const shuffled = selectedWord.split('').sort(() => Math.random() - 0.5).join('');
    
    setWord(selectedWord);
    setJumbledWord(shuffled);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userAnswer.toUpperCase() === word) {
      onWin();
    } else {
      onLose();
    }
  };

  return (
    <div className="text-center space-y-8">
      <h3 className="text-2xl font-bold text-gray-800">Word Unscramble</h3>
      <p className="text-gray-600">Unscramble the letters to form a word!</p>
      
      <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-8 rounded-2xl">
        <div className="text-4xl font-bold text-purple-600 tracking-widest mb-6">
          {jumbledWord}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <input
          type="text"
          value={userAnswer}
          onChange={(e) => setUserAnswer(e.target.value)}
          placeholder="Enter the correct word"
          className="w-full max-w-md mx-auto p-4 border-2 border-gray-300 rounded-xl text-lg text-center font-semibold transition-all duration-300 focus:border-purple-500 focus:outline-none focus:shadow-lg"
          autoFocus
        />
        
        <div className="flex gap-4 justify-center">
          <button
            type="submit"
            className="bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
          >
            <span className="flex items-center gap-2">
              <Send size={18} />
              Submit Answer
            </span>
          </button>
          
          <button
            type="button"
            onClick={onBack}
            className="bg-gradient-to-r from-gray-500 to-gray-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
          >
            <span className="flex items-center gap-2">
              <RotateCcw size={18} />
              Back to Seats
            </span>
          </button>
        </div>
      </form>
    </div>
  );
}
