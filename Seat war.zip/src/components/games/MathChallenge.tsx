import React, { useState, useEffect } from 'react';
import { RotateCcw, Calculator, Clock } from 'lucide-react';
import { GameProps } from '../../types';

interface MathProblem {
  question: string;
  answer: number;
  options: number[];
}

export default function MathChallenge({ onWin, onLose, onBack }: GameProps) {
  const [currentProblem, setCurrentProblem] = useState<MathProblem | null>(null);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [gameStatus, setGameStatus] = useState<'playing' | 'won' | 'lost'>('playing');
  const [feedback, setFeedback] = useState<string>('');

  useEffect(() => {
    generateNewProblem();
    
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          if (score >= 5) {
            setGameStatus('won');
            setTimeout(() => onWin(), 1500);
          } else {
            setGameStatus('lost');
            setTimeout(() => onLose(), 1500);
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const generateNewProblem = () => {
    const operations = ['+', '-', '*'];
    const operation = operations[Math.floor(Math.random() * operations.length)];
    
    let num1, num2, answer;
    
    switch (operation) {
      case '+':
        num1 = Math.floor(Math.random() * 50) + 1;
        num2 = Math.floor(Math.random() * 50) + 1;
        answer = num1 + num2;
        break;
      case '-':
        num1 = Math.floor(Math.random() * 50) + 25;
        num2 = Math.floor(Math.random() * 25) + 1;
        answer = num1 - num2;
        break;
      case '*':
        num1 = Math.floor(Math.random() * 12) + 1;
        num2 = Math.floor(Math.random() * 12) + 1;
        answer = num1 * num2;
        break;
      default:
        num1 = 1; num2 = 1; answer = 2;
    }

    const question = `${num1} ${operation} ${num2}`;
    
    // Generate wrong options
    const wrongOptions = [];
    while (wrongOptions.length < 3) {
      const wrong = answer + (Math.floor(Math.random() * 20) - 10);
      if (wrong !== answer && wrong > 0 && !wrongOptions.includes(wrong)) {
        wrongOptions.push(wrong);
      }
    }
    
    const options = [answer, ...wrongOptions].sort(() => Math.random() - 0.5);
    
    setCurrentProblem({ question, answer, options });
    setFeedback('');
  };

  const handleAnswer = (selectedAnswer: number) => {
    if (gameStatus !== 'playing' || !currentProblem) return;

    if (selectedAnswer === currentProblem.answer) {
      const newScore = score + 1;
      setScore(newScore);
      setFeedback('✅ Correct!');
      
      if (newScore >= 5) {
        setGameStatus('won');
        setFeedback('🎉 You solved 5 problems! You win!');
        setTimeout(() => onWin(), 1500);
      } else {
        setTimeout(() => generateNewProblem(), 1000);
      }
    } else {
      setFeedback(`❌ Wrong! The answer was ${currentProblem.answer}`);
      setTimeout(() => generateNewProblem(), 1500);
    }
  };

  return (
    <div className="text-center space-y-8">
      <div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Math Challenge</h3>
        <p className="text-gray-600">Solve 5 math problems in 60 seconds!</p>
        <div className="mt-4 flex justify-center gap-8 text-lg font-semibold">
          <div className="flex items-center gap-2">
            <Calculator className="text-green-600" size={20} />
            <span>Score: {score}/5</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="text-red-600" size={20} />
            <span>Time: {timeLeft}s</span>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-green-100 to-teal-100 p-8 rounded-2xl">
        {currentProblem && (
          <>
            <div className="text-4xl font-bold text-gray-800 mb-8">
              {currentProblem.question} = ?
            </div>

            {feedback && (
              <div className={`text-lg font-bold p-4 rounded-xl mb-6 ${
                feedback.includes('Correct') || feedback.includes('win') ? 'bg-green-200 text-green-800' :
                feedback.includes('Wrong') ? 'bg-red-200 text-red-800' :
                'bg-gray-200 text-gray-800'
              }`}>
                {feedback}
              </div>
            )}

            {gameStatus === 'playing' && !feedback.includes('Wrong') && (
              <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
                {currentProblem.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswer(option)}
                    className="bg-white border-2 border-gray-300 rounded-xl p-6 text-2xl font-bold transition-all duration-300 hover:scale-105 hover:border-teal-400 hover:shadow-lg hover:shadow-teal-100"
                  >
                    {option}
                  </button>
                ))}
              </div>
            )}
          </>
        )}

        {gameStatus === 'won' && (
          <div className="text-2xl font-bold text-green-600">
            🏆 Mathematical Genius! 🏆
          </div>
        )}

        {gameStatus === 'lost' && (
          <div className="text-2xl font-bold text-red-600">
            ⏰ Time's up! Better luck next time!
          </div>
        )}
      </div>

      <button
        onClick={onBack}
        className="bg-gradient-to-r from-gray-500 to-gray-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
      >
        <span className="flex items-center gap-2">
          <RotateCcw size={18} />
          Back to Seats
        </span>
      </button>
    </div>
  );
}
