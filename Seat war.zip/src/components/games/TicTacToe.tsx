import React, { useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { GameProps } from '../../types';

export default function TicTacToe({ onWin, onLose, onBack }: GameProps) {
  const [board, setBoard] = useState<string[]>(Array(9).fill(''));
  const [gameOver, setGameOver] = useState(false);

  const checkWin = (boardState: string[], player: string): boolean => {
    const winPatterns = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
      [0, 4, 8], [2, 4, 6] // diagonals
    ];
    
    return winPatterns.some(pattern => 
      pattern.every(index => boardState[index] === player)
    );
  };

  const getAIMove = (boardState: string[]): number => {
    const emptyIndices = boardState
      .map((cell, index) => cell === '' ? index : null)
      .filter(index => index !== null) as number[];
    
    return emptyIndices.length > 0 
      ? emptyIndices[Math.floor(Math.random() * emptyIndices.length)]
      : -1;
  };

  const makeMove = (index: number) => {
    if (board[index] !== '' || gameOver) return;

    const newBoard = [...board];
    newBoard[index] = 'X';
    setBoard(newBoard);

    if (checkWin(newBoard, 'X')) {
      setGameOver(true);
      setTimeout(() => onWin(), 1000);
      return;
    }

    // AI move
    setTimeout(() => {
      const aiMove = getAIMove(newBoard);
      if (aiMove !== -1) {
        const aiBoard = [...newBoard];
        aiBoard[aiMove] = 'O';
        setBoard(aiBoard);

        if (checkWin(aiBoard, 'O')) {
          setGameOver(true);
          setTimeout(() => onLose(), 1000);
        }
      }
    }, 500);
  };

  return (
    <div className="text-center space-y-6">
      <h3 className="text-2xl font-bold text-gray-800">Tic Tac Toe - You are X</h3>
      
      <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto">
        {board.map((cell, index) => (
          <button
            key={index}
            onClick={() => makeMove(index)}
            className="w-20 h-20 bg-white border-2 border-gray-300 rounded-xl text-2xl font-bold transition-all duration-200 hover:bg-gray-50 hover:scale-105 flex items-center justify-center"
            disabled={gameOver}
          >
            <span className={cell === 'X' ? 'text-blue-600' : cell === 'O' ? 'text-red-500' : ''}>
              {cell}
            </span>
          </button>
        ))}
      </div>

      <button
        onClick={onBack}
        className="bg-gradient-to-r from-gray-500 to-gray-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
      >
        <span className="flex items-center gap-2">
          <RotateCcw size={18} />
          Back to Seats
        </span>
      </button>
    </div>
  );
}
