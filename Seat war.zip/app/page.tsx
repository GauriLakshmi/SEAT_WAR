"use client"

import { useState, useEffect, useCallback } from "react"
import LoginForm from "../src/components/LoginForm"
import SeatSelection from "../src/components/SeatSelection"
import GameContainer from "../src/components/GameContainer"
import ShuffleContainer from "../src/components/ShuffleContainer"
import type { User as UserType, GameType } from "../src/types"

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserType | null>(null)
  const [selectedSeat, setSelectedSeat] = useState<number | null>(null)
  const [originalSelectedSeat, setOriginalSelectedSeat] = useState<number | null>(null)
  const [bookedSeats, setBookedSeats] = useState<Set<number>>(new Set())
  const [currentView, setCurrentView] = useState<"login" | "seats" | "game" | "shuffle">("login")
  const [currentGame, setCurrentGame] = useState<GameType | null>(null)

  const initializeBookedSeats = useCallback(() => {
    const totalSeats = 56
    const bookedCount = Math.floor(totalSeats * 0.7)
    const seatNumbers = Array.from({ length: totalSeats }, (_, i) => i + 1)

    // Shuffle array
    for (let i = seatNumbers.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[seatNumbers[i], seatNumbers[j]] = [seatNumbers[j], seatNumbers[i]]
    }

    setBookedSeats(new Set(seatNumbers.slice(0, bookedCount)))
  }, [])

  useEffect(() => {
    initializeBookedSeats()
  }, [initializeBookedSeats])

  const handleLogin = (user: UserType) => {
    setCurrentUser(user)
    setCurrentView("seats")
  }

  const handleSeatSelect = (seatNumber: number) => {
    setSelectedSeat(seatNumber)
    setOriginalSelectedSeat(seatNumber)
  }

  const handleConfirmBooking = () => {
    if (selectedSeat && bookedSeats.has(selectedSeat)) {
      // Start random game
      const games: GameType[] = [
        "ticTacToe",
        "jumbledWords",
        "rockPaperScissors",
        "colorMemory",
        "numberGuessing",
        "simonSays",
        "mathChallenge",
      ]
      const randomGame = games[Math.floor(Math.random() * games.length)]
      setCurrentGame(randomGame)
      setCurrentView("game")
    } else {
      // Start shuffle
      setCurrentView("shuffle")
    }
  }

  const handleGameWin = () => {
    if (selectedSeat) {
      setBookedSeats((prev) => {
        const newSet = new Set(prev)
        newSet.delete(selectedSeat)
        return newSet
      })
    }
    setTimeout(() => {
      setCurrentView("shuffle")
    }, 2000)
  }

  const handleGameLose = () => {
    setTimeout(() => {
      setCurrentView("seats")
      resetSelection()
    }, 2000)
  }

  const resetSelection = () => {
    setSelectedSeat(null)
    setOriginalSelectedSeat(null)
    setCurrentGame(null)
  }

  const resetToStart = () => {
    setCurrentView("seats")
    resetSelection()
    initializeBookedSeats()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-purple-600 bg-[length:200%_200%] animate-gradient-shift flex items-center justify-center p-4">
      <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 p-8 md:p-12 max-w-4xl w-full">
        {currentView === "login" && <LoginForm onLogin={handleLogin} />}

        {currentView === "seats" && currentUser && (
          <SeatSelection
            user={currentUser}
            bookedSeats={bookedSeats}
            selectedSeat={selectedSeat}
            onSeatSelect={handleSeatSelect}
            onConfirmBooking={handleConfirmBooking}
            onBackToSeats={resetSelection}
          />
        )}

        {currentView === "game" && currentGame && (
          <GameContainer
            gameType={currentGame}
            onGameWin={handleGameWin}
            onGameLose={handleGameLose}
            onBackToSeats={() => setCurrentView("seats")}
          />
        )}

        {currentView === "shuffle" && originalSelectedSeat && (
          <ShuffleContainer
            originalSeat={originalSelectedSeat}
            bookedSeats={bookedSeats}
            onResetToStart={resetToStart}
          />
        )}
      </div>
    </div>
  )
}
