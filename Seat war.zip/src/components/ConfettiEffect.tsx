import React, { useEffect } from 'react';

export default function ConfettiEffect() {
  useEffect(() => {
    const colors = ['#f39c12', '#e74c3c', '#9b59b6', '#3498db', '#2ecc71', '#e67e22', '#f1c40f', '#e91e63'];
    const confettiElements: HTMLElement[] = [];

    for (let i = 0; i < 100; i++) {
      const confetti = document.createElement('div');
      confetti.style.position = 'fixed';
      confetti.style.width = '8px';
      confetti.style.height = '8px';
      confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
      confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
      confetti.style.pointerEvents = 'none';
      confetti.style.zIndex = '1000';
      
      // Start from center
      confetti.style.left = '50%';
      confetti.style.top = '50%';
      confetti.style.transform = 'translate(-50%, -50%)';
      
      // Random burst direction
      const angle = (Math.PI * 2 * i) / 100;
      const velocity = Math.random() * 300 + 200;
      const finalX = Math.cos(angle) * velocity;
      const finalY = Math.sin(angle) * velocity;
      
      document.body.appendChild(confetti);
      confettiElements.push(confetti);
      
      // Animate burst
      setTimeout(() => {
        confetti.style.transition = 'all 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
        confetti.style.transform = `translate(${finalX}px, ${finalY}px) rotate(${Math.random() * 720}deg)`;
      }, 50);
      
      // Fall animation
      setTimeout(() => {
        confetti.style.transition = 'all 3s linear';
        confetti.style.transform = `translate(${finalX + (Math.random() - 0.5) * 200}px, 100vh) rotate(${Math.random() * 1440}deg)`;
        confetti.style.opacity = '0';
      }, 700);
    }

    // Cleanup
    const cleanup = setTimeout(() => {
      confettiElements.forEach(el => {
        if (el.parentNode) {
          el.parentNode.removeChild(el);
        }
      });
    }, 4000);

    return () => {
      clearTimeout(cleanup);
      confettiElements.forEach(el => {
        if (el.parentNode) {
          el.parentNode.removeChild(el);
        }
      });
    };
  }, []);

  return null;
}
