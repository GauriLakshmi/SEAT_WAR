import React, { useState, useEffect } from 'react';
import { Home } from 'lucide-react';
import ConfettiEffect from './ConfettiEffect';

interface ShuffleContainerProps {
  originalSeat: number;
  bookedSeats: Set<number>;
  onResetToStart: () => void;
}

export default function ShuffleContainer({ originalSeat, bookedSeats, onResetToStart }: ShuffleContainerProps) {
  const [isShuffling, setIsShuffling] = useState(true);
  const [finalSeat, setFinalSeat] = useState<number | null>(null);
  const [shuffleMessage, setShuffleMessage] = useState('');
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      performShuffle();
    }, 4000);

    return () => clearTimeout(timer);
  }, []);

  const performShuffle = () => {
    const shouldShuffle = Math.random() < 0.7;
    let newSeat = originalSeat;
    
    if (shouldShuffle) {
      const availableSeats = [];
      for (let i = 1; i <= 56; i++) {
        if (!bookedSeats.has(i)) {
          availableSeats.push(i);
        }
      }
      
      const filteredSeats = availableSeats.filter(seat => seat !== originalSeat);
      if (filteredSeats.length > 0) {
        newSeat = filteredSeats[Math.floor(Math.random() * filteredSeats.length)];
      }
    }

    const originalIsVIP = originalSeat <= 16;
    const finalIsVIP = newSeat <= 16;
    
    let message = '';
    if (newSeat !== originalSeat) {
      if (!originalIsVIP && finalIsVIP) {
        message = '🎉 SURPRISE UPGRADE! 🎉\nYou got bumped up to VIP! Lucky you!';
      } else if (originalIsVIP && !finalIsVIP) {
        message = '😅 Plot Twist! 😅\nYou\'ve been moved to a regular seat. Life happens!';
      } else {
        message = `🔄 Seat Shuffle! 🔄\nYou got a different ${finalIsVIP ? 'VIP' : 'regular'} seat!`;
      }
    } else {
      message = '🍀 Lucky Day! 🍀\nThe universe decided you deserve to keep your original seat!';
    }

    setFinalSeat(newSeat);
    setShuffleMessage(message);
    setIsShuffling(false);
    setShowConfetti(true);
  };

  if (isShuffling) {
    return (
      <div className="text-center space-y-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          🎲 Seat Shuffle Time!
        </h1>
        
        <div className="bg-gradient-to-br from-red-400 via-pink-500 to-purple-600 bg-[length:300%_300%] animate-pulse p-12 rounded-3xl text-white text-center">
          <h2 className="text-2xl font-bold mb-6">🔀 The universe is deciding your fate...</h2>
          <div className="w-16 h-16 border-4 border-white/30 border-t-white rounded-full animate-spin mx-auto mb-6"></div>
          <p className="text-lg opacity-90">
            Your seat is being shuffled! You might get a surprise upgrade or... well, life is unpredictable! 😄
          </p>
        </div>
      </div>
    );
  }

  const seatTypeEmoji = (finalSeat && finalSeat <= 16) ? "👑" : "🪑";

  return (
    <div className="text-center space-y-8">
      {showConfetti && <ConfettiEffect />}
      
      <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
        🎊 Shuffle Complete! 🎊
      </h1>

      <div className="space-y-6">
        {shuffleMessage && (
          <div className={`p-6 rounded-2xl font-bold text-lg ${
            shuffleMessage.includes('UPGRADE') 
              ? 'bg-gradient-to-r from-yellow-400 to-orange-500 text-yellow-900 animate-pulse'
              : shuffleMessage.includes('Plot Twist')
              ? 'bg-gradient-to-r from-blue-400 to-blue-600 text-blue-900'
              : shuffleMessage.includes('Shuffle')
              ? 'bg-gradient-to-r from-green-400 to-teal-500 text-green-900'
              : 'bg-gradient-to-r from-green-400 to-green-600 text-green-900'
          }`}>
            {shuffleMessage.split('\n').map((line, index) => (
              <div key={index}>{line}</div>
            ))}
          </div>
        )}

        {finalSeat && (
          <div className="text-7xl p-8 bg-white/20 border-4 border-white rounded-3xl inline-block animate-bounce">
            {seatTypeEmoji} Seat {finalSeat}
          </div>
        )}

        <div className="text-lg text-gray-700">
          {finalSeat !== originalSeat ? (
            <p>Originally selected: Seat {originalSeat} → Final seat: Seat {finalSeat}</p>
          ) : (
            <p>You kept your original choice: Seat {finalSeat}</p>
          )}
        </div>

        <p className="text-lg text-purple-600 font-medium">
          Congratulations! Your booking is confirmed! 🎉
        </p>

        <button
          onClick={onResetToStart}
          className="bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold py-4 px-8 rounded-2xl transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-green-200 mt-8"
        >
          <span className="flex items-center gap-2">
            <Home size={20} />
            Book Another Seat
          </span>
        </button>
      </div>
    </div>
  );
}
