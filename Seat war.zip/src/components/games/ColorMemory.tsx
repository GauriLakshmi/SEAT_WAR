import React, { useState, useEffect } from 'react';
import { RotateCcw } from 'lucide-react';
import { GameProps } from '../../types';

const colors = [
  { name: 'red', bg: 'bg-red-500', hover: 'hover:bg-red-600' },
  { name: 'blue', bg: 'bg-blue-500', hover: 'hover:bg-blue-600' },
  { name: 'green', bg: 'bg-green-500', hover: 'hover:bg-green-600' },
  { name: 'yellow', bg: 'bg-yellow-500', hover: 'hover:bg-yellow-600' },
  { name: 'purple', bg: 'bg-purple-500', hover: 'hover:bg-purple-600' },
  { name: 'orange', bg: 'bg-orange-500', hover: 'hover:bg-orange-600' }
];

export default function ColorMemory({ onWin, onLose, onBack }: GameProps) {
  const [sequence, setSequence] = useState<number[]>([]);
  const [playerSequence, setPlayerSequence] = useState<number[]>([]);
  const [showingSequence, setShowingSequence] = useState(false);
  const [activeColor, setActiveColor] = useState<number | null>(null);
  const [round, setRound] = useState(1);
  const [gameStatus, setGameStatus] = useState<'waiting' | 'showing' | 'playing' | 'won' | 'lost'>('waiting');

  useEffect(() => {
    startNewRound();
  }, []);

  const startNewRound = () => {
    const newSequence = [...sequence, Math.floor(Math.random() * colors.length)];
    setSequence(newSequence);
    setPlayerSequence([]);
    setGameStatus('showing');
    showSequence(newSequence);
  };

  const showSequence = async (seq: number[]) => {
    setShowingSequence(true);
    
    for (let i = 0; i < seq.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 600));
      setActiveColor(seq[i]);
      await new Promise(resolve => setTimeout(resolve, 400));
      setActiveColor(null);
    }
    
    setShowingSequence(false);
    setGameStatus('playing');
  };

  const handleColorClick = (colorIndex: number) => {
    if (showingSequence || gameStatus !== 'playing') return;

    const newPlayerSequence = [...playerSequence, colorIndex];
    setPlayerSequence(newPlayerSequence);

    // Check if this click is correct
    if (newPlayerSequence[newPlayerSequence.length - 1] !== sequence[newPlayerSequence.length - 1]) {
      setGameStatus('lost');
      setTimeout(() => onLose(), 1000);
      return;
    }

    // Check if sequence is complete
    if (newPlayerSequence.length === sequence.length) {
      if (round >= 5) {
        setGameStatus('won');
        setTimeout(() => onWin(), 1000);
      } else {
        setRound(round + 1);
        setTimeout(() => startNewRound(), 1000);
      }
    }
  };

  return (
    <div className="text-center space-y-8">
      <div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Color Memory</h3>
        <p className="text-gray-600">Memorize and repeat the color sequence!</p>
        <div className="mt-4 text-lg font-semibold">
          Round {round} of 5 | Sequence length: {sequence.length}
        </div>
      </div>

      <div className="bg-gradient-to-r from-indigo-100 to-purple-100 p-8 rounded-2xl">
        {gameStatus === 'waiting' && (
          <p className="text-lg text-gray-600">Get ready...</p>
        )}
        {gameStatus === 'showing' && (
          <p className="text-lg text-purple-600 font-semibold">Watch the sequence!</p>
        )}
        {gameStatus === 'playing' && (
          <p className="text-lg text-green-600 font-semibold">
            Repeat the sequence ({playerSequence.length}/{sequence.length})
          </p>
        )}
        {gameStatus === 'won' && (
          <p className="text-lg text-green-600 font-bold">🎉 Perfect! You won!</p>
        )}
        {gameStatus === 'lost' && (
          <p className="text-lg text-red-600 font-bold">❌ Wrong sequence!</p>
        )}

        <div className="grid grid-cols-3 gap-4 max-w-sm mx-auto mt-6">
          {colors.map((color, index) => (
            <button
              key={color.name}
              onClick={() => handleColorClick(index)}
              disabled={showingSequence || gameStatus === 'won' || gameStatus === 'lost'}
              className={`
                w-20 h-20 rounded-2xl transition-all duration-200 border-4 border-white shadow-lg
                ${color.bg} ${color.hover}
                ${activeColor === index ? 'scale-110 brightness-125 border-white shadow-xl' : ''}
                ${showingSequence ? 'cursor-not-allowed' : 'hover:scale-105'}
                disabled:opacity-50
              `}
            />
          ))}
        </div>
      </div>

      <button
        onClick={onBack}
        className="bg-gradient-to-r from-gray-500 to-gray-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
      >
        <span className="flex items-center gap-2">
          <RotateCcw size={18} />
          Back to Seats
        </span>
      </button>
    </div>
  );
}
