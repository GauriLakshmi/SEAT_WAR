export interface User {
  name: string
  phone: string
}

export type GameType =
  | "ticTacToe"
  | "jumbledWords"
  | "rockPaperScissors"
  | "colorMemory"
  | "numberGuessing"
  | "simonSays"
  | "mathChallenge"

export interface GameProps {
  onWin: () => void
  onLose: () => void
  onBack: () => void
}
